#!/bin/bash

if [[ -z "$1" ]]; then
    write_error "You need to use this script with a parameter. (Either 'ci', 'cd' or 'notification')"
    exit 1
fi

# Initialising git configuration here because terraform modules are stored in private git repositories.

if [[ "$1" == "ci" ]]; then
    echo "CI Pipeline started.."
    features=$(ls -1 *.feature | sed s/\.feature//g)
    git_root_dir=$(pwd)
    test_root_dir="$git_root_dir/tests"

    cd "$test_root_dir"
    for test_module in $features;
    do
        if [ ! -d "$test_module" ]; then
            echo "Could not find any test written for $test_module feature."
            exit 1
        fi

        # Get into the feature test directory
        cd "$test_module"

        # Copy the feature file temporarily
        cp "$git_root_dir/$test_module.feature" .

        for test_item in $(find . -maxdepth 1 -type d -name "test*");
        do
            echo "$test_module: Running tests: $test_item"
            cd "$test_item"

            test_type="pass"
            wip=""
            if [ -f ".fail" ]; then
                test_type="fail"
                wip="--wip"
            fi
            echo "$test_module: Expecting a ** $test_type ** on $test_item tests."

            # Running test
            # We first init, then plan
            terraform init -no-color > .error.log && terraform plan -no-color -out plan.out >> .error.log
            echo "$test_module: Terraform plan created."

            # Just an extra control
            if [ $? -ne 0 ]; then
                cat .error.log
                echo "$test_module: Can not create terraform plan for $test_type tests for $test_item."
                exit 1
            fi

            echo "$test_module: Running compliance test."
            terraform-compliance -f ../ -p plan.out --no-ansi $wip

            # Checking the exit code.
            if [ $? -ne 0 ]; then
                cat .error.log
                echo "$test_module: $test_item tests are failed. I was expecting a $test_type instead."
                exit 1
            fi

            # Return back to the feature test root.
            cd ..
            echo "$test_module: $test_item tests passed. Expected $test_type and got it."
        done

        rm "./$test_module.feature"
        echo "$test_module: All tests passed."

        # Return back to the module root.
        cd ..

    done

    echo "All tests passed as expected."
    echo "CI Pipeline finished."
    exit 0
fi
