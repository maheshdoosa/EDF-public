export ARM_CLIENT_ID=$1
export ARM_CLIENT_SECRET=$2
export ARM_SUBSCRIPTION_ID=$3
export ARM_TENANT_ID=$4

git fetch origin master
echo "Finding changed modules."
changed_modules=$(git diff --name-only $(git rev-parse origin/master) HEAD | cut -d "/" -f1 | grep azure- | uniq)
echo "Changed_modules: $changed_modules"

for module in $changed_modules;
do
    echo "Module: $module"
    cd "./$module"

    if [ ! -d "test" ]; then
        echo "Could not find any 'test' directory for $module module."
        exit 1
    fi

    cd test
    echo "Running tests for $module module."
    terraform init && terraform plan -no-color -out plan_$module.out

    if [ $? -ne 0 ]; then
        echo "Tests failed for $module module."
        exit 1
    fi
    
    #compliance_repo_url=git:ssh://github.com/edfenergy/edf-rap-security-compliance-scenarios.git
    compliance_repo_url="../../"
    echo "Running Azure EDF-wide compliance tests against infrastructure-as-code"

    terraform-compliance -f "$compliance_repo_url" -p plan_$module.out --no-ansi --early-exit --formatter dots

    if [ $? -ne 0 ]; then
        echo "Compliance tests failed for $module module."
        exit 1
    fi

    echo "Compliance tests passed for $module module."

    # Return back to the module root.
    cd ..

    # Return back to the git root.
    cd ..

done