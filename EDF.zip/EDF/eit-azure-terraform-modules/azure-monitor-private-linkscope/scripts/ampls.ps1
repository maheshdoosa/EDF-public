
param ($spSecret, $tenantId, $spApplicationId, $name, $resourceGroupName)

#Below coammand to log in Azure with Service Principle
az login --service-principal -u $spApplicationId -p $spSecret --tenant $tenantId

#Below command will deploy the Azure Monitor Private Linkscope
az monitor private-link-scope create --name $name  --resource-group $resourceGroupName



