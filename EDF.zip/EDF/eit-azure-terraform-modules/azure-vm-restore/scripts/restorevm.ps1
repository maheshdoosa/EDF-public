﻿
####################### parameters #####################
param ($RecoveryServiceVaultName, $RSVRGname, $vmName, $resourceGroupName, $storageAccountName, $spApplicationId, $spSecret, $tenantId, $subscriptionId)

###################### connecting to Azure using SP ###################
$userPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $userPassword)
Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

####################### PART-1 Creating OS and Data disk from restore point ############################################

#set recovery service vault context

Get-AzRecoveryServicesVault -Name $RecoveryServiceVaultName -ResourceGroupName $RSVRGname | Set-AzRecoveryServicesVaultContext


$targetVault = Get-AzRecoveryServicesVault -ResourceGroupName $RSVRGname -Name $RecoveryServiceVaultName

$targetVault.ID

#set vm that we need to retore

$namedContainer = Get-AzRecoveryServicesBackupContainer  -ContainerType "AzureVM" -Status "Registered" -FriendlyName $vmName -VaultId $targetVault.ID

$backupitem = Get-AzRecoveryServicesBackupItem -Container $namedContainer  -WorkloadType "AzureVM" -VaultId $targetVault.ID

#get reovery points for vm in last 7 days

$startDate = (Get-Date).AddDays(-7)

$endDate = Get-Date

$rp = Get-AzRecoveryServicesBackupRecoveryPoint -Item $backupitem -StartDate $startdate.ToUniversalTime() -EndDate $enddate.ToUniversalTime() -VaultId $targetVault.ID

#latest reovery point

$rp[0]

#restore the from last recovery point to the storage account of our choice also creates os and data disks

#$restorejob = Restore-AzRecoveryServicesBackupItem -RecoveryPoint $rp[0] -StorageAccountName $storageAccountName -StorageAccountResourceGroupName $resourceGroupName -TargetResourceGroupName $resourceGroupName -VaultId $targetVault.ID -RestoreDiskList $disks

$restorejob = Restore-AzRecoveryServicesBackupItem -RecoveryPoint $rp[0] -StorageAccountName $storageAccountName -StorageAccountResourceGroupName $resourceGroupName -TargetResourceGroupName $resourceGroupName -VaultId $targetVault.ID -RestoreOnlyOSDisk

$restorejob

$diskList= Get-AzResource -ResourceType "Microsoft.Compute/disks" -ResourceGroupName $resourceGroupName -TagName "RSVaultBackup" -TagValue $restorejob.JobID

do { 
    Write-Host "Waiting for OS and Data Disk creation to complete" 
    Start-Sleep -Seconds 5 
    $diskList= Get-AzResource -ResourceType "Microsoft.Compute/disks" -ResourceGroupName $resourceGroupName -TagName "RSVaultBackup" -TagValue $restorejob.JobID

} while($diskList.Count -lt 2)
Write-Output ("OS and Data disks created Successfully...")


################################## Part-1 END ################################################################
