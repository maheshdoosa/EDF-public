﻿####################### parameters #####################
param ($sourceResourceGroupName, $targetResourceGroupName, $newDiskname, $spApplicationId, $spSecret, $tenantId, $subscriptionId)

###################### connecting to Azure using SP ###################
$userPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $userPassword)
Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

##################### copying restored vm disk to destination RG ################
$managedDisks = @() 

$managedDisks = Get-AzDisk -ResourceGroupName $sourceResourceGroupName

$managedDisks | ForEach-Object { 
   
    $names = $_.Name.Split('-')

    #$diskName = "$newDiskname-$($names[1])-$($names[2])" ## commented due to retrive the current datadisk name in feature if we follow the data disn name as -01 etc we need to enable this line. 

    $diskName = "$newDiskname-$($names[1])"

    $diskConfig = New-AzDiskConfig -SourceResourceId $_.Id -Location $_.Location -CreateOption Copy -Tag $_.Tags

    Write-Host "Waiting for $diskName Disk copying to complete" 


    $result=New-AzDisk -Disk $diskConfig -DiskName $diskName -ResourceGroupName $targetResourceGroupName

    Start-Sleep -Seconds 10

    Write-Output ("$diskName disks copied Successfully...")
}