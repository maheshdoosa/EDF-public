﻿
####################### parameters #####################
param ($vmresourceGroupName, $vmName, $resourceGroupName, $disks, $spApplicationId, $spSecret, $tenantId, $subscriptionId)

###################### connecting to Azure using SP ###################
$userPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $userPassword)
Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

###################### swap the datadisk #######################

$diskList= Get-AzResource -ResourceType "Microsoft.Compute/disks" -ResourceGroupName $resourceGroupName -TagName "RSVaultBackup" #-TagValue $restorejob.JobID

if ($diskList[0].Name.Contains('datadisk'))
{
$dataDisk=$diskList[0]
$osDisk=$diskList[1]
}
else
{
$dataDisk=$diskList[1]
$osDisk=$diskList[0]
}

#Stopping the VM

Stop-AzVM -ResourceGroupName $vmresourceGroupName -Name $vmName -Force;

$VirtualMachine = Get-AzVM -ResourceGroupName $vmresourceGroupName -Name $vmName

$currentVmDisk = ((Get-AzVM -resourcegroupname $vmresourceGroupName -name $vmname).StorageProfile).DataDisks[$disks]

Remove-AzVMDataDisk -VM $VirtualMachine -Name $currentVmDisk[$disks].Name

Update-AzVM -ResourceGroupName $vmresourceGroupName -VM $VirtualMachine 

Write-Output ("Successfully removed current vm disk...")

########## Fetching restored data disk for swapping ##############

$newaDataDisk = Get-AzDisk -ResourceGroupName $resourceGroupName -DiskName $dataDisk.Name ###>> data.txt

$datadisk_id=$newaDataDisk.Id ####>>data1.txt

#echo "display data disk id"
#echo $resourceGroupName
#echo $dataDisk
#echo $datadisk_id

#echo "ending dispaly"

Add-AzVMDataDisk -CreateOption Attach -Lun $disks -VM $VirtualMachine -ManagedDiskId $datadisk_id

# Update the VM with the Data disk
Update-AzVM -ResourceGroupName $vmresourceGroupName -VM $VirtualMachine 

# Start the VM
Start-AzVM -Name $vmName -ResourceGroupName $vmresourceGroupName

Write-Output ("Swapped the Data disk successfully and restart completed...")