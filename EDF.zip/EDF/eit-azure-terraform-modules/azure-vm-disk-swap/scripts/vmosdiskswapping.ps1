﻿
####################### parameters #####################
param ($vmresourceGroupName, $vmName, $resourceGroupName, $spApplicationId, $spSecret, $tenantId, $subscriptionId)

###################### connecting to Azure using SP ###################
$userPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $userPassword)
Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

###################### Fatching restored disk with tag value #######################

$diskList= Get-AzResource -ResourceType "Microsoft.Compute/disks" -ResourceGroupName $resourceGroupName -TagName "RSVaultBackup" #-TagValue $restorejob.JobID

if ($diskList[0].Name.Contains('datadisk'))
{
$dataDisk=$diskList[0]
$osDisk=$diskList[1]
}
else
{
$dataDisk=$diskList[1]
$osDisk=$diskList[0]
}

####################Fetching the current VM #######

$VirtualMachine = Get-AzVM -ResourceGroupName $vmresourceGroupName -Name $vmName

####################Fetching the names of the current OS Disk for removing finally#######

$oldOsDiskName = ((Get-AzVM -resourcegroupname $vmresourceGroupName -name $vmname).StorageProfile).OsDisk

#Stopping the VM

Stop-AzVM -ResourceGroupName $vmresourceGroupName -Name $vmName -Force;

#Swaping the Os disk 

# Set the VM configuration to point to the new disk  

Set-AzVMOSDisk -VM $VirtualMachine -ManagedDiskId $osDisk.ResourceId -Name $osDisk.Name

# Update the VM with the new OS disk

Update-AzVM -ResourceGroupName $vmresourceGroupName -VM $VirtualMachine 

# Start the VM

Start-AzVM -Name $vmName -ResourceGroupName $vmresourceGroupName


Write-Output ("Swapped the Os disk successfully and restart completed...")

