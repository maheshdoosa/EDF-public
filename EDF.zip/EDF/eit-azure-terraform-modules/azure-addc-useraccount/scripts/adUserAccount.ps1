Param ($ouname, $oupath, $testpass, $description, $UserPrincipalName, $firstname, $lastname, $DisplayName, $Department)
$testpass           = $testpass.Split(" ")
$description        = $description.Split(",")
$UserPrincipalName  = $UserPrincipalName.Split(",")
$firstname          = $firstname.Split(",")
$lastname           = $lastname.Split(",")
$DisplayName        = $DisplayName.Split(",")
$Department         = $Department.Split(",")
$ouname             = $ouname.Split(",")
$Existingou_users=@{}

#Create a list of users that already exists in AD


for($i = 0; $i -lt $ouname.length; $i++) { 
    $destou="OU=$($ouname[$i]),$oupath"
    $ArrayList= New-Object System.Collections.ArrayList
    Get-ADUser -Filter * -SearchBase $destou | Select sAMAccountName | % { $ArrayList.Add($_.samaccountname) }
    $Existingou_users["$($ouname[$i])"] = $ArrayList
}

for($i = 0; $i -lt $firstname.length; $i++) { 
  $psw = convertto-securestring $testpass[$i] -asplaintext -force
  $destou="OU=$($ouname[$i]),$oupath"
  $SamAccountName = "$($firstname[$i]).$($lastname[$i])"
  
  #Check if the user account already exists in AD

  if (Get-ADUser -Filter * -SearchBase $destou | where sAMAccountName -EQ $SamAccountName)
    {  
                       
      #Check the list of users and remove the existing users from the list
      $Existingou_users["$($ouname[$i])"].Remove($SamAccountName)

      #If user does exist, output a warning message
      Write-Warning "A user account $($firstname[$i]) $($lastname[$i]) already exist in Active Directory."
    }
  else
    {
      #If a user does not exist then create a new user account
             
      New-ADUser -SamAccountName $SamAccountName -UserPrincipalName "$($firstname[$i]).$($lastname[$i])" -Name "$($firstname[$i]) $($lastname[$i])" -GivenName $firstname[$i] -Surname $lastname[$i] -Enabled $true -ChangePasswordAtLogon $true -DisplayName "$($firstname[$i]).$($lastname[$i])" -Path $destou -AccountPassword $psw
      Write-Output "$($DisplayName[$i]) user account created in $destou"
  
    }
}
#If a user does not exist in the provided list then delete the user account from AD

foreach($OU in $Existingou_users.keys) {
  foreach($user in $Existingou_users[$OU]) {
  $user=$user.replace("."," ")
  Remove-ADUser -Identity "CN=$user,OU=$OU,$oupath" -Confirm:$false
  }
}