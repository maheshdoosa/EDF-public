#  This script is will create deployment schedules for Update Management.

param ($logFilePath, $automationAccountName, $resourceGroupName, $tenantId, $arrayFilePath, $spSecret, $spApplicationId)
 
$a = Get-Date
$Date = $a.ToString("yyyyMMdd") 
$Time = $a.ToString("hhmm")

$logfile = "$logFilePath\Update Mgmt-$date-$time.log"

Function LogWrite
{
    Param ([string]$logstring)

    Add-content $logfile -value $logstring
}

function TimeStamp {
    
    return "[{0:MM/dd/yy} {0:HH:mm:ss}]" -f (Get-Date)
    
}

#  Build the array
#  This will use the array.csv file.
 
$ScheduleConfig = Get-Content -Path $arrayFilePath | ConvertFrom-Csv
 
#  Schedule Deployments Start Here
 
$scope = "/subscriptions/$((Get-AzContext).subscription.id)"
$QueryScope = @($scope)
 
$WindowsSchedules = $ScheduleConfig | Where-Object {$_.OS -eq "Windows"}
$LinuxSchedules = $ScheduleConfig | Where-Object {$_.OS -eq "Linux"}
 
foreach($WindowsSchedule in $WindowsSchedules){
 
$tag = @{$WindowsSchedule.TagName=$WindowsSchedule.TagValue}
$azq = New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $resourceGroupName `
                                       -AutomationAccountName $automationAccountName `
                                       -Scope $QueryScope `
                                       -Tag $tag
 
$AzureQueries = @($azq)
 
$date=((get-date).AddDays(1)).ToString("yyyy-MM-dd")
$time=$WindowsSchedule.Starttime
$datetime= $date + "t" + $time
 
$startTime = [DateTimeOffset]"$datetime"
$duration = New-TimeSpan -Hours 2

try {
$schedule = New-AzAutomationSchedule -ResourceGroupName $resourceGroupName `
                                                  -AutomationAccountName $automationAccountName `
                                                  -Name $WindowsSchedule.ScheduleName `
                                                  -StartTime $StartTime `
                                                  -DayofWeek $WindowsSchedule.DayofWeek `
                                                  -DayofWeekOccurrence $WindowsSchedule.DaysofWeekOccurrence `
                                                  -MonthInterval 1 `
                                                  -ForUpdateConfiguration `
                                                  -Verbose
 
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $resourceGroupName `
                                                 -AutomationAccountName $automationAccountName `
                                                 -Schedule $schedule `
                                                 -Windows `
                                                 -Azurequery $AzureQueries `
                                                 -IncludedUpdateClassification Critical,Security,Updates,UpdateRollup,Definition `
                                                 -Duration $duration `
                                                 -RebootSetting $WindowsSchedule.Reboot `
                                                 -Verbose

Logwrite "$(TimeStamp) - Successfully created the Windows Schedule-$schedule "
    }


catch {

Logwrite $Error[0].Exception.Message
Logwrite "$(TimeStamp) - Failed to create Windows Schedule-$schedule"

      }

}
 
foreach ($LinuxSchedule in $LinuxSchedules){
 
$tag = @{$LinuxSchedule.TagName=$LinuxSchedule.TagValue}
$azq = New-AzAutomationUpdateManagementAzureQuery -ResourceGroupName $resourceGroupName `
                                       -AutomationAccountName $automationAccountName `
                                       -Scope $QueryScope `
                                       -Tag $tag
 
$AzureQueries = @($azq)
 
$date=((get-date).AddDays(1)).ToString("yyyy-MM-dd")
$time=$LinuxSchedule.Starttime
$datetime= $date + "t" + $time
 
$startTime = [DateTimeOffset]"$datetime"
$duration = New-TimeSpan -Hours 2

try {

$schedule = New-AzAutomationSchedule -ResourceGroupName $resourceGroupName `
                                                  -AutomationAccountName $automationAccountName `
                                                  -Name $LinuxSchedule.ScheduleName `
                                                  -StartTime $StartTime `
                                                  -DayofWeek $LinuxSchedule.DayofWeek `
                                                  -DayofWeekOccurrence $LinuxSchedule.DaysofWeekOccurrence `
                                                  -MonthInterval 1 `
                                                  -ForUpdateConfiguration `
                                                  -Verbose
 
New-AzAutomationSoftwareUpdateConfiguration -ResourceGroupName $resourceGroupName `
                                                 -AutomationAccountName $automationAccountName `
                                                 -Schedule $schedule `
                                                 -Linux `
                                                 -Azurequery $AzureQueries `
                                                 -IncludedPackageClassification Critical,Security `
                                                 -Duration $duration `
                                                 -RebootSetting $LinuxSchedule.Reboot `
                                                 -Verbose

Logwrite "$(TimeStamp) - Successfully created the Linux Schedule-$schedule "

    }

catch {

Logwrite $Error[0].Exception.Message
Logwrite "$(TimeStamp) - Failed to create Linux Schedule-$schedule"

      }

}

Write-host "All Schedule has been created successfully"