#!/bin/bash

eval "$(jq -r '@sh "export Secret_Name=\(.secretName) Vault_Name=\(.vaultName) SP_Name=\(.spName) SP_SECRET=\(.spSecret) Tenant=\(.tenant) SubscriptionId=\(.subscriptionId)"')"

az login --service-principal -u "${SP_Name}" -p "${SP_SECRET}" --tenant "${Tenant}"
az account set --subscription "${SubscriptionId}"

if [ -z "${Secret_Name}" ]
then
    kvSecretValue=""
else
    kvSecretValue=$(az keyvault secret show --name "${Secret_Name}" --vault-name "${Vault_Name}" --query "value" -o tsv)
fi

jq -n --arg kvSecretValue "$kvSecretValue" '{"kvSecretValue":$kvSecretValue}'