Param ($ouname, $destou, $Deleteou)
$ouname= $ouname.Split(",")
$Deleteou= $Deleteou.Split(",")

 $ArrayList= New-Object System.Collections.ArrayList
 Get-ADOrganizationalUnit -Filter 'name -like "*"' | % { $ArrayList.Add($_.name) }

foreach($ou in $ouname) { 
if ($ArrayList.Contains($ou))
    {  
		#If a OU exist then skip it.
	Write-Warning "OU $ou already exist in Active Directory."
    }
  else
    {
		#If OU doesn't exist, Create a new OU.
    	New-ADOrganizationalUnit -Name $ou -path $destou
	    Write-Output "$ou OU account created in $destou"
        $ArrayList.Add($ou)
	
	}  
}

foreach($ou in $Deleteou) {
if ($ArrayList.Contains($ou))
    {  
		#If a OU exist then delete it.

    Get-ADOrganizationalUnit -Identity "OU=$ou,$destou" | Set-ADObject -ProtectedFromAccidentalDeletion:$false -PassThru | Remove-ADOrganizationalUnit -Confirm:$false

	Write-Output "$ou OU account deleted in $destou"
    $ArrayList.Remove($ou)
    }
  else
    {
        #If Security group doesn't exist, output a warning message
      Write-Warning "Cannot delete a OU $ou as it doesn't exist in Active Directory."
	}  
}