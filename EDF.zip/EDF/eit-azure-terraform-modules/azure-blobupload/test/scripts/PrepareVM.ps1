# Xml File Location
$xmlFile = "https://eituksalzhsauxscript.blob.core.windows.net/scripts/settings.xml?sp=r&st=2020-12-15T11:36:27Z&se=2020-12-15T19:36:27Z&spr=https&sv=2019-12-12&sr=b&sig=1j8UovKpdHI4bbhQ3Y5XpEfPPKzCaE1Pj2YgGdxXF18%3D"
 
# Storage account URL to download the xml file.
Invoke-WebRequest  $xmlFile -OutFile C:\Temp\GBRegion.xml


# Create C:\Temp directory
New-Item -ItemType Directory -Path "C:\Temp" -Force
 
# Move CDROM to Z:\
(gwmi Win32_cdromdrive).drive | %{$a = mountvol $_ /l;mountvol $_ /d;$a = $a.Trim();mountvol z: $a}
 
# Change Timezone
tzutil /s "GMT Standard Time"
 
# Change System Locale & Language
Set-WinSystemLocale en-GB
Set-WinHomeLocation -GeoId 242
Set-Culture en-GB
& $env:SystemRoot\System32\control.exe "intl.cpl,,/f:`"C:\Temp\GBRegion.xml`""

# Label C:\
Set-Volume -DriveLetter C -NewFileSystemLabel "SYSTEM"
 
# Disable IE Enhanced Security Configuration for Administrators
$AdminKey = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
Set-ItemProperty -Path $AdminKey -Name IsInstalled -Value 0
 
# Unbind IPv6 from the Network Adapter
$NIC = Get-NetAdapterBinding | where-object {$_.ComponentID -eq "ms_tcpip6"}
Disable-NetAdapterBinding -Name $NIC.Name -ComponentID "ms_tcpip6"