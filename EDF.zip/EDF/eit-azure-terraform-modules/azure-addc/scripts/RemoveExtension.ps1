param ($extName, $resourceGroupName, $vmName, $spSecret, $tenantId, $subscriptionId, $spApplicationId)

#$userIdPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
#$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $spSecret)
#Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

#Remove the vm extension
Remove-AzVMCustomScriptExtension -Name $extName -ResourceGroupName $resourceGroupName -VMName $vmName -force