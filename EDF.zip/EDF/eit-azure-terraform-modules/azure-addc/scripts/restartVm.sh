#!/bin/bash

az vm restart -g $resourceGroupName -n $vmName