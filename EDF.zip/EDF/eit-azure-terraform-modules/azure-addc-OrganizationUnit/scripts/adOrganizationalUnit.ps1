Param ($oulist, $oupath)
$oulist= $oulist.Split(",")

  $oulist | Foreach-Object {
  $ouname = ''
  $ous = (Split-Path $_ -Parent).Split('\')
  [array]::Reverse($ous)
  $ous | Foreach-Object {
    if ($_.Length -eq 0) {
      return
    }
    $ouname = $ouname + 'OU=' + $_ + ','
  }
  $ouname += $oupath
  $newou = Split-Path $_ -Leaf

  New-ADOrganizationalUnit -Name "$newou" -Path "$ouname" -ProtectedFromAccidentalDeletion $true
}