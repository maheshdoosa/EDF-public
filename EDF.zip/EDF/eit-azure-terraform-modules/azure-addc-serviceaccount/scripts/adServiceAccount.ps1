Param ($SAtestuser, $SAtestpass, $description, $ouname, $oupath)
$SAtestuser = $SAtestuser.Split(",")
$SAtestpass = $SAtestpass.Split(" ")
$description = $description.Split(",")

function New-ServiceAccount {
    Param
    (
        [Parameter(Mandatory=$true)]
        [string]
        $samaccountname,
         [Parameter(Mandatory=$true)]
        [string]
        $description,
         [Parameter(Mandatory=$true)]
        [string]
        $password,
         [Parameter(Mandatory=$true)]
        [string]
         $destou
    )
    $psw = convertto-securestring "$password" -asplaintext -force
    New-ADUser -Path $destou -Name "$samaccountname"  -AccountPassword $psw -Enabled $true -AllowReversiblePasswordEncryption $false -CannotChangePassword $true -PasswordNeverExpires $true
    Write-Output "$samaccountname service account created in $destou"
}
    $destou="OU=$ouname,$oupath"
    $Existinguser= New-Object System.Collections.ArrayList
    Get-ADUser -Filter * -SearchBase $destou | Select sAMAccountName | % { $Existinguser.Add($_.samaccountname) }
 
for($i = 0; $i -lt $SAtestuser.length; $i++) {
if (Get-ADUser -Filter * -SearchBase $destou | where sAMAccountName -EQ $SAtestuser[$i])
    {               
      #Check the list of users and remove the existing users from the list
      $Existinguser.Remove($SAtestuser[$i])

      #If user does exist, output a warning message
      Write-Warning "A Service Account $($SAtestuser[$i]) already exist in Active Directory."
    }
  else
    {
      #If a user does not exist then create a new user account        
      New-ServiceAccount -samaccountname $SAtestuser[$i] -description $description[$i] -password $SAtestpass[$i] -destou $destou  
    }
}
#If a user does not exist in the provided list then delete the user account from AD

  foreach($user in $Existinguser) {
  Remove-ADUser -Identity $user -Confirm:$false
  }