Param ($sgname, $description, $sgpath, $GroupCategory, $GroupScope, $DisplayName, $Deletesg)
$sgname         = $sgname.Split(",")
$description    = $description.Split(",")
$DisplayName    = $DisplayName.Split(",")
$Deletesg		= $Deletesg.Split(",")

for($i = 0; $i -lt $sgname.length; $i++) { 
if (Get-ADGroup -Filter * -SearchBase $sgpath | where sAMAccountName -EQ $sgname[$i])
    {  
      #If Security group does exist, output a warning message
      Write-Warning "A Security Group $sgname already exist in Active Directory."
    }
  else
    {
      #If a Security group does not exist then create a new one.
	New-ADGroup -Name $sgname[$i] -SamAccountName $sgname[$i] -GroupCategory $GroupCategory -GroupScope $GroupScope -DisplayName $DisplayName[$i] -Path $sgpath -Description $description[$i]

	Write-Output "$sgname SG account created in $sgpath"
	}  
}

foreach($sg in $Deletesg) {

if (Get-ADGroup -Filter * -SearchBase $sgpath | where sAMAccountName -EQ $sg)
    {  
		#If a Security group does exist then delete it.
	Remove-ADGroup -Identity $sg -confirm:$false
	Write-Output "$sg SG account deleted in $sgpath"
    }
  else
    {
        #If Security group doesn't exist, output a warning message
      Write-Warning "Cannot delete a Security Group $sg as it doesn't exist in Active Directory."
	}  
}