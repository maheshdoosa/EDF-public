param ($resourceGroupName, $storageAccountName, $container, $immutabilityPeriod, $spApplicationId, $spSecret, $tenantId, $subscriptionId)

$userPassword = ConvertTo-SecureString -String $spSecret -AsPlainText -Force
$pscredential = New-Object -TypeName System.Management.Automation.PSCredential($spApplicationId, $userPassword)
Connect-AzAccount -ServicePrincipal -Credential $pscredential -Tenant $tenantId -Subscription $subscriptionId

# Create an immutability policy with appends allowed
Set-AzRmStorageContainerImmutabilityPolicy -ResourceGroupName $resourceGroupName -StorageAccountName $storageAccountName -ContainerName $container -ImmutabilityPeriod $immutabilityPeriod -AllowProtectedAppendWrite $true

# Get an immutability policy
Get-AzRmStorageContainerImmutabilityPolicy -ResourceGroupName $resourceGroupName -StorageAccountName $storageAccountName -ContainerName $container

# Lock immutability policies (add -Force to dismiss the prompt):
$policy = Get-AzRmStorageContainerImmutabilityPolicy -ResourceGroupName $resourceGroupName -StorageAccountName $storageAccountName -ContainerName $container
Lock-AzRmStorageContainerImmutabilityPolicy -ImmutabilityPolicy $policy -force