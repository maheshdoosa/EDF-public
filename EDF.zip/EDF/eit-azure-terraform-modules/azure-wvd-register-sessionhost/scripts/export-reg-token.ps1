param ($resourcegroupname, $hostpoolname, $storageaccname, $storagekey, $stgcontainername)

#create a registration token to authorize a session host to join the host pool.

New-AzWvdRegistrationInfo -ResourceGroupName $resourcegroupname -HostPoolName $hostpoolname -ExpirationTime $((get-date).ToUniversalTime().AddHours(3).ToString('yyyy-MM-ddTHH:mm:ss.fffffffZ'))

#Commands to export the registration token to a variable, which you will use later in Register the virtual machines to the Windows Virtual Desktop host pool.

Get-AzWvdRegistrationInfo -ResourceGroupName $resourcegroupname -HostPoolName $hostpoolname | Select-Object -ExpandProperty "token" | Out-File -FilePath ".\token.txt" -Force

#coammdns to upload the generated token in storage account container

$jbcontext=New-AzStorageContext -StorageAccountName $storageaccname -StorageAccountKey $storagekey

Set-AzStorageBlobContent -Container $stgcontainername -File ".\token.txt" -BlobType Block -Context $jbcontext -Force

Start-Sleep 20

Remove-Item –path ".\token.txt"

