#parameter are not supported because this script will be run on VM as unattended method

Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force

#Get token for registration
#Actual path is mandatory to metion othrewise it will fail

$RegToken= Get-content -Path "C:/Packages/Plugins/Microsoft.Compute.CustomScriptExtension/1.10.9/Downloads/0/token.txt"

#Set Variables
$RootFolder = "C:\Packages\Plugins\"
$WVDAgentInstaller = $RootFolder+"WVD-Agent.msi"
$WVDBootLoaderInstaller = $RootFolder+"WVD-BootLoader.msi"

#Create Folder structure
if (!(Test-Path -Path $RootFolder)){New-Item -Path $RootFolder -ItemType Directory}

Set-ExecutionPolicy -ExecutionPolicy Bypass -force
#Import-Module -Name Az.DesktopVirtualization

#Configure logging
function log
{
   param([string]$message)
   "`n`n$(get-date -f o)  $message" 
}

#Set WVD Agent and Boot Loader download locations
$WVDAgentDownkloadURL = "https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrmXv"
$WVDBootLoaderDownkloadURL = "https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrxrH"


#Install the WVD Agent
Log "Install the WVD Agent"
Invoke-WebRequest -Uri $WVDAgentDownkloadURL -OutFile $WVDAgentInstaller
Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $WVDAgentInstaller", "/quiet", "/qn", "/norestart", "/passive", "REGISTRATIONTOKEN=$RegToken", "/l* C:\Users\AgentInstall.txt" | Wait-process

#Wait to ensure WVD Agent has enought time to finish
Start-sleep 15

#Install the WVD Bootloader
Log "Install the Boot Loader"
Invoke-WebRequest -Uri $WVDBootLoaderDownkloadURL -OutFile $WVDBootLoaderInstaller
Start-Process -FilePath "msiexec.exe" -ArgumentList "/i $WVDBootLoaderInstaller", "/quiet", "/qn", "/norestart", "/passive", "/l* C:\Users\AgentBootLoaderInstall.txt" | Wait-process

Log "Finished"