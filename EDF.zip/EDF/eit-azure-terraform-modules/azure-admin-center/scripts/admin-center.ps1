
Set-ExecutionPolicy -ExecutionPolicy Unrestricted -Force

Install-PackageProvider "NuGet" -MinimumVersion 2.8 -Force

#To get the latest installer from the Microsoft website 
$WAC_Online = "http://aka.ms/WACDownload" #this is static value so hard coded
$WAC_Installer = "C:\windows\Temp\wac.msi"
$WAC_Log = "C:\windows\Temp\wac-installer.log"
Invoke-WebRequest -Uri $WAC_Online -OutFile $WAC_Installer

#To install it and using port 443 and a self-signed certificate
msiexec /i $WAC_Installer /qn SME_PORT=443 SSL_CERTIFICATE_OPTION=generate

