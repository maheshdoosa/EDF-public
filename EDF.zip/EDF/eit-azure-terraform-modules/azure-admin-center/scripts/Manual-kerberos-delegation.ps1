#Below script will be run manually to add keberos delegation 

$ServerB2 = Get-ADComputer -Identity admincenterserver1 #this is first admin center server name
$ServerB3 = Get-ADComputer -Identity admincenterserver2 #this is second admin center server name
$ServerC  = Get-ADComputer -Identity vmnaame #it's vm name which will be added as nodes in admin center

#Below script to add keberos delegation
Set-ADComputer -Identity $ServerC  -PrincipalsAllowedToDelegateToAccount @($ServerB2,$ServerB3)