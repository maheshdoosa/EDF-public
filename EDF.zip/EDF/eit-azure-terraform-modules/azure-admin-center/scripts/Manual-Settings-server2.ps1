#This script to be run manually on Secoond admin center server. Change the URL and names required in below script as per environment

# Load the module
Import-Module "$env:ProgramFiles\windows admin center\PowerShell\Modules\ConnectionTools"

# Export connections of second admin center server to a .csv file
Export-Connection "https://admincenter2.domain.com" -fileName "WAC-connections-server2.csv"

#Copy connection file to First admin center server
Copy-Item "C:\Users\safeadmin.AZURE\WAC-connections-server2.csv" -Destination "\\admincenter1\c$\Admin Center Settings"

#Import connetion file of First admin center server
Import-Connection "https://admincenter1.domain.com" -fileName "c:\Admin Center Settings\WAC-connections-server1.csv"
