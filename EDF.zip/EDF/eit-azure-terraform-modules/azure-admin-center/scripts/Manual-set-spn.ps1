
#Below script to be run manually for adding spn of the VMs which will be added as nodes in Admin center
Invoke-command -computerName eituksstgads01 -Scriptblock { klist purge -li 0x3e7 }

setspn admincenter-sva -d http/eituksstgadmc5

