#This script to be run manually on First admin center server. Change the URL and names required in below script as per environment

# Load the module
Import-Module "$env:ProgramFiles\windows admin center\PowerShell\Modules\ConnectionTools"

# Export connections of First admin center server to a .csv file
Export-Connection "https://admincenter1.domain.com" -fileName "WAC-connections-server1.csv"

#Copy connection file to second admin center server
Copy-Item "C:\Users\safeadmin.AZURE\WAC-connections-server1.csv" -Destination "\\admincenter2\c$\Admin Center Settings"

#Import connetion file of second admin center server
Import-Connection "https://admincenter2.domain.com" -fileName "c:\Admin Center Settings\WAC-connections-server2.csv"
