param ($SubscriptionId, $ResourceGroupName, $poolname, $workspacename, $HostPoolType, $LoadBalancerType,
 $servicelocation, $DesktopAppGroupName, $customproperties, $DesktopAppFriendlyName, 
 $HostpoolFriendlyName, $appgroupdescription, $appgrouptype)

#set the subscription
Set-AzContext -SubscriptionId $SubscriptionId
    
Install-Module -Name Az.DesktopVirtualization -AllowClobber -Force

Import-Module -Name Az.DesktopVirtualization

#register the Azure resource Provider

az provider register --namespace "Microsoft.DesktopVirtualization"

Start-Sleep -s 45

#create the host pool, workspace and desktop app group. Additionally, it will register the desktop app group to the workspace.

New-AzWvdHostPool -ResourceGroupName $ResourceGroupName -Name $poolname -WorkspaceName $workspacename -HostPoolType $HostPoolType -LoadBalancerType $LoadBalancerType -Location $servicelocation -DesktopAppGroupName $DesktopAppGroupName -SubscriptionId $SubscriptionId -PreferredAppGroupType $appgrouptype

#Below coammands make the changes in WVD custom properties

Start-Sleep -s 45

Update-AzWvdHostPool -ResourceGroupName $ResourceGroupName -Name $poolname  -CustomRdpProperty $customproperties -FriendlyName $HostpoolFriendlyName

Update-AzWvdApplicationGroup -name $DesktopAppGroupName -FriendlyName $DesktopAppFriendlyName -ResourceGroupName $ResourceGroupName -Description $appgroupdescription