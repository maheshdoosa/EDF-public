# eit-azure-lz-env-init

## Changelog Guide

Refer to below instruction guide to know how `CHANGELOG.md` gets updated
<https://digitalcentral.edfenergy.com/pages/viewpage.action?pageId=186029053>
