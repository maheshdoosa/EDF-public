# Azure DevOps Project Automation

This automation helps in the creation of new Azure DevOps project, cloning repositories, and transferring Wiki from a source organization to a client organization. The automation is implemented using Terraform scripts and is triggered through a YAML pipeline.

## Prerequisites

To successfully run this automation script, ensure that you have the following prerequisites in place:

- Azure DevOps organization accounts for client organizations.
- Access to the Azure DevOps source organization (PAT) with FULL permissions on the repositories.
- Access to the Azure DevOps client organization (PAT) with sufficient permissions to create projects and repositories.

## Setup

To set up and run the automation script, follow these steps:

1. **Store the value of Destination organization's PAT in Variable Group** Start by adding the Client Organization's PAT to variable 'destination_pat' in the Variable Group 'azDevOpsProject'.


2. **Trigger the Pipeline** Open Azure DevOps Pipelines, go to "DevOps_Projects" pipeline, Click on "Run Pipeline", and provide the required details:

   - **source_organization_url:** URL of the source Azure DevOps organization.
   - **destination_organization_pat:** Personal Access Token (PAT) for the destination Azure DevOps organization.
   - **destination_organization_url:** URL of the destination Azure DevOps organization.
   - **project_name:** Name of the new project to be created in the destination organization.
   - **project_process:** Select the Azure DevOps Project process. The default value is "agile".
   - **repositories_to_clone:** Names of the repositories to be cloned from the source organization to the destination organization. Provide the names of repositories in the following format:
     ```json
     {
        "repositories": [
            {
                "repo_name": "Repo-1",
                "branch": []
            },
            {
                "repo_name": "Repo-2",
                "branch": []
            }
        ]
     }
     ```
   - **deploy_wiki:** Choose whether to deploy the Azure DevOps Wiki to the repository in the destination organization.
   - **checkUser:** Choose whether to add users to the client organization.
   - **users:** List of users to be added to the client organization. Enter the email addresses of users, separated by ";".
   - **check_extensions:** Choose whether to install extensions in the client organization.
   - **extensions:** JSON with details of the extensions to be installed. Provide the extension IDs and publisher IDs in the following format:
     ```json
     {
         "extensions": [
             {
                 "id": "extension-id-1",
                 "publisher_id": "publisher-id-1"
             },
             {
                 "id": "extension-id-2",
                 "publisher_id": "publisher-id-2"
             },
             ...
         ]
     }
     ```
   - **check_org_policies:** Choose whether to add organization policies to the client organization.
   - **org_policies:** Update the values of the policies as per the requirement. Provide the policy values in the following format:
     ```json
     {
         "policies": {
             "policy_name_1": policy_value_1,
             "policy_name_2": policy_value_2,
             ...
         }
     }
     ```
   - **check_org_settings:** Choose whether to update organization settings in the client organization.
   - **org_settings:** Update the values of the settings as per the requirement. Provide the setting values in the following format:
     ```json
     {
         "settings": {
             "setting_name_1": setting_value_1,
             "setting_name_2": setting_value_2,
             ...
         }
     }
     ```
   - **connect_to_azure_active_directory:** Choose whether to connect to Azure Active Directory.
   - **tenant_id:** Tenant ID of the Azure Active Directory.
   - **check_branch_policies:** Choose whether to update branch policies in the client organization.
   - **branch_policies:** Update the values of the branch policies as per the requirement. Provide the policy values in the following format:
     ```json
     {
         "policies": {
             "policy_name_1": [
                 {
                     "repository_name": "Repo-1",
                     "branch_name": "Branch-1",
                     "branch_match_type": "prefix",
                     "policy_property_1": policy_value_1,
                     "policy_property_2": policy_value_2,
                     ...
                 },
                 ...
             ],
             ...
         }
     }
     ```
   - **check_service_endpoints:** Choose whether to create service endpoints in the client organization.
   - **service_endpoints:** JSON with details of the service endpoints to be created. Provide the service endpoint details in the following format:
     ```json
     {
         "service_endpoints": [
             {
                 "azurerm": [],
                 "github": []
             },
             ...
         ]
     }
     ```
   - **check_variable_groups:** Choose whether to create variable groups in the client organization.
   - **variable_groups:** JSON with details of the variable groups to be created. Provide the variable group details in the following format:
     ```json
     {
         "variable_groups": [
             {
                 "name": "VariableGroup-1",
                 "description": "Description of VariableGroup-1",
                 "variables": [
                     {
                         "key": "Variable-1",
                         "value": "Value-1",
                         "isSecret": false
                     },
                     ...
                 ]
             },
             ...
         ]
     }
     ```
   - **check_pipelines:** Choose whether to create pipelines in the client organization.
   - **pipelines:** JSON with details of the pipelines to be created. Provide the pipeline details in the following format:
     ```json
     {
         "pipelines": [
             {
                 "name": "Pipeline-1",
                 "folder_name": "/",
                 "repository_name": "Repo-1",
                 "pipeline_path": "Path/to/Pipeline-1.yaml"
             },
             ...
         ]
     }
     ```
   - **check_security_groups:** Choose whether to create security groups in the client organization.
   - **security_groups:** JSON with details of the security groups to be created. Provide the security group details in the following format:
     ```json
     {
         "security_groups": [
             {
                 "name": "SecurityGroup-1",
                 "description": "Description of SecurityGroup-1"
             },
             ...
         ]
     }
     ```
   - **check_environments:** Choose whether to create pipeline environments in the client organization.
   - **check_sg_assignments:** Choose whether to assign security groups to pipeline environments in the client organization.
   - **environments:** JSON with details of the pipeline environments to be created. Provide the environment details in the following format:
     ```json
     {
         "environments": [
             {
                 "name": "Environment-1",
                 "description": "Description of Environment-1",
                 "security_groups_name": [
                     {
                         "name": "SecurityGroup-1",
                         "role_name": "User"
                     },
                     ...
                 ]
             },
             ...
         ]
     }
     ```

## Result

Upon successful execution of the automation script, the following actions will be performed:

- Creation of a new Azure DevOps project in the client organization.
- Cloning of the specified repositories from the source organization to the client organization.
- Deployment of the Azure DevOps Wiki to the repository in the client organization (if chosen).
- Addition of users to the client organization (if chosen).
- Installation of extensions in the client organization (if chosen).
- Addition of organization policies to the client organization (if chosen).
- Update of organization settings in the client organization (if chosen).
- Connection to Azure Active Directory (if chosen).
- Update of branch policies in the client organization (if chosen).
- Creation of service endpoints in the client organization (if chosen).
- Creation of variable groups in the client organization (if chosen).
- Creation of pipelines in the client organization (if chosen).
- Creation of security groups in the client organization (if chosen).
- Creation of pipeline environments in the client organization (if chosen).
- Assignment of security groups to pipeline environments in the client organization (if chosen).

## Notes

- Make sure you have appropriate permissions and access to both the source and client Azure DevOps organizations.
- Verify that the repository and wiki names provided in the configuration file are accurate and exist in the source organization.
- This automation script is intended for Azure DevOps project setup and repository cloning, and may require modification for additional customizations.

## Troubleshooting

If you encounter any issues or errors during the execution of the automation script, please refer to the following resources:

- Azure DevOps documentation: [https://docs.microsoft.com/azure/devops/](https://docs.microsoft.com/azure/devops/)
- Terraform documentation: [https://www.terraform.io/docs/](https://www.terraform.io/docs/)

For further assistance, feel free to reach out to the maintainers of this repository.