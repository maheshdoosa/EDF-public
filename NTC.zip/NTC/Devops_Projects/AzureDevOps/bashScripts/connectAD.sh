function connecting_organization_to_azure_active_directory {
    local ORG_NAME=$1
    local TENANT_ID=$2
    local PAT=$3
    echo "TENANT_ID: $TENANT_ID"
    echo "Connecting to $TENANT_ID tenant Azure Active Directory"
    echo "Check if the $ORG_NAME organization is already connected to Azure Active Directory"
    RESPONSE=$(curl --silent \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            "https://dev.azure.com/$ORG_NAME/_settings/organizationAad?__rt=fps&__ver=2")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the retrieval of the list of existing Azure Active Directories"
        return 1;
    else
        echo "SUCCESS: The list of existing Azure Active Directories was retrieved successfully"
    fi
    if [[ $(echo "$RESPONSE_BODY" | jq -r '.fps.dataProviders.data."ms.vss-admin-web.organization-admin-aad-data-provider".orgnizationTenantData.domain') != "" ]]; then    
        DISPLAY_NAME=$(echo "$RESPONSE_BODY" | jq -r '.fps.dataProviders.data."ms.vss-admin-web.organization-admin-aad-data-provider".orgnizationTenantData.displayName')
        echo "DISPLAY_NAME: $DISPLAY_NAME"
        ID=$(echo "$RESPONSE_BODY" | jq -r '.fps.dataProviders.data."ms.vss-admin-web.organization-admin-aad-data-provider".orgnizationTenantData.id')
        echo "ID: $ID"
        DOMAIN=$(echo "$RESPONSE_BODY" | jq -r '.fps.dataProviders.data."ms.vss-admin-web.organization-admin-aad-data-provider".orgnizationTenantData.domain')
        echo "DOMAIN: $DOMAIN"
        echo "WARNING: The $ORG_NAME organization is already connected to the $DISPLAY_NAME ($ID) Azure Active Directory. Skipping..."
        return 0
    else
        echo "The $ORG_NAME organization is not connected to Azure Active Directory. Connecting..."
    fi
    echo "URL: https://vssps.dev.azure.com/$ORG_NAME/_apis/Organization/Organizations/Me?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/TenantId","value":"'$TENANT_ID'"}]' \
            "https://vssps.dev.azure.com/$ORG_NAME/_apis/Organization/Organizations/Me?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the connection to Azure Active Directory. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Connection to Azure Active Directory was successful"
    fi
}