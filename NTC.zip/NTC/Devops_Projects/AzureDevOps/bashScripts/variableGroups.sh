function create_pipeline_variable_groups {
    local ORG_NAME=$1
    local PROJECT_NAME=$2
    local DEFAULT_JSON=$3
    echo "Creating variable group in $PROJECT_NAME project"
    for VARIABLE_GROUPS in $(echo "$DEFAULT_JSON" | jq -r '.variable_groups[] | @base64'); do
        VARIABLE_GROUPS_JSON=$(echo "$VARIABLE_GROUPS" | base64 --decode | jq -r '.')
        echo "VARIABLE_GROUPS_JSON: $VARIABLE_GROUPS_JSON"
        NAME=$(echo "$VARIABLE_GROUPS_JSON" | jq -r '.name')
        echo "NAME: $NAME"
        DESCRIPTION=$(echo "$VARIABLE_GROUPS_JSON" | jq -r '.description')
        echo "DESCRIPTION: $DESCRIPTION"
        VARIABLE_PARAMETER=""
        for VARIABLE in $(echo "$VARIABLE_GROUPS_JSON" | jq -r '.variables[] | @base64'); do
            KEY=$(echo "$VARIABLE" | base64 --decode | jq -r '.key')
            VALUE=$(echo "$VARIABLE" | base64 --decode | jq -r '.value')
            VARIABLE_PARAMETER="$VARIABLE_PARAMETER ${KEY}=${VALUE}"
        done
        echo "VARIABLE_PARAMETER: $VARIABLE_PARAMETER"
        echo "Checking if $NAME variable group already exists"
        echo "Command: az pipelines variable-group list --organization https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME --output json | jq -r '.[] | select(.name == "'"$NAME"'") | .id'"
        GROUP_ID=$(az pipelines variable-group list --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --output json | jq -r '.[] | select(.name == "'"$NAME"'") | .id')
        echo "GROUP_ID: $GROUP_ID"
        if [ -n "$GROUP_ID" ]; then
            echo "WARNING: Variable group $NAME already exists with ID $GROUP_ID. Skipping..."
            continue
        else
            echo "Variable group $NAME does not exist"
        fi
        echo "Creating $NAME variable group..."
        echo "Command: az pipelines variable-group create --name $NAME --description $DESCRIPTION --variables $VARIABLE_PARAMETER --organization https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME"
        az pipelines variable-group create --name "$NAME" --description "$DESCRIPTION" --variables $VARIABLE_PARAMETER --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: $NAME variable group created successfully"
        else
            echo "ERROR: Failed to create $NAME variable group"
            return 1
        fi
        GROUP_ID=$(az pipelines variable-group list --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --output json | jq -r '.[] | select(.name == "'"$NAME"'") | .id')
        echo "GROUP_ID: $GROUP_ID"
        echo "Updating $NAME Variables Secrecy"
        for VARIABLE in $(echo "$VARIABLE_GROUPS_JSON" | jq -r '.variables[] | @base64'); do
            KEY=$(echo "$VARIABLE" | base64 --decode | jq -r '.key')
            ISSECRET=$(echo "$VARIABLE" | base64 --decode | jq -r '.isSecret')
            az pipelines variable-group variable update --group-id "$GROUP_ID" --name "$KEY" --secret "$ISSECRET" --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME"
        done
    done
}