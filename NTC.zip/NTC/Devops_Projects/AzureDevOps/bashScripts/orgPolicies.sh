function configure_organization_policies {
    local ORG_ID=$1
    local ORG_NAME=$2
    local DEFAULT_JSON=$3
    local PAT=$4
    echo "Values of input parameters - "
    echo "$ORG_ID"
    echo "$ORG_NAME"
    echo "$DEFAULT_JSON"
    echo "$PAT"
    echo "Configure ${ORG_NAME} organization policies"
    THIRD_PARTY_ACCESS_VIA_OAUTH=$(echo "$DEFAULT_JSON" | jq -r '.policies.disallow_third_party_application_access_via_oauth')
    echo "Setting Third-party application access via OAuth to $THIRD_PARTY_ACCESS_VIA_OAUTH"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowOAuthAuthentication?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$THIRD_PARTY_ACCESS_VIA_OAUTH'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowOAuthAuthentication?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Third-party application access via OAuth policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Third-party application access via OAuth policy was successful"
    fi
    SSH_AUTHENTICATION=$(echo "$DEFAULT_JSON" | jq -r '.policies.disallow_ssh_authentication')
    echo "Setting SSH authentication to $SSH_AUTHENTICATION"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowSecureShell?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$SSH_AUTHENTICATION'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowSecureShell?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE") 
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the SSH authentication policy. $RESPONSE_BODY"
        return 1;
    else
        echo "Configuration of the SSH authentication policy was successful"
    fi
    LOG_AUDIT_EVENTS=$(echo "$DEFAULT_JSON" | jq -r '.policies.log_audit_events')
    echo "Setting Log audit events to $LOG_AUDIT_EVENTS"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.LogAuditEvents?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$LOG_AUDIT_EVENTS'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.LogAuditEvents?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Log audit events policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Log audit events policy was successful"
    fi
    ALLOW_PUBLIC_PROJECTS=$(echo "$DEFAULT_JSON" | jq -r '.policies.allow_public_projects')
    echo "Setting Allow public projects to $ALLOW_PUBLIC_PROJECTS"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowAnonymousAccess?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ALLOW_PUBLIC_PROJECTS'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowAnonymousAccess?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Allow public projects policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Allow public projects policy was successful"
    fi
    ARTIFACTS_EXTERNAL_PACKAGE_PROTECTION_TOKEN=$(echo "$DEFAULT_JSON" | jq -r '.policies.additional_protections_public_package_registries')
    echo "Setting Additional protections for public package registries to $ARTIFACTS_EXTERNAL_PACKAGE_PROTECTION_TOKEN"
    echo "Url: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.ArtifactsExternalPackageProtectionToken?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ARTIFACTS_EXTERNAL_PACKAGE_PROTECTION_TOKEN'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.ArtifactsExternalPackageProtectionToken?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Additional protections for public package registries policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Additional protections for public package registries policy was successful"
    fi
    ENFORCE_AZURE_ACTIVE_DIRECTORY_CONDITIONAL_ACCESS=$(echo "$DEFAULT_JSON" | jq -r '.policies.enable_azure_active_directory_conditional_access_policy_validation')
    echo "Setting Additional protections for public package registries to $ENFORCE_AZURE_ACTIVE_DIRECTORY_CONDITIONAL_ACCESS"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.EnforceAADConditionalAccess?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ENFORCE_AZURE_ACTIVE_DIRECTORY_CONDITIONAL_ACCESS'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.EnforceAADConditionalAccess?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Additional protections for public package registries policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Additional protections for public package registries policy was successful"
    fi
    ALLOW_TEAM_ADMINS_INVITATIONS_ACCESS_TOKEN=$(echo "$DEFAULT_JSON" | jq -r '.policies.allow_team_and_project_administrators_to_invite_new_users')
    echo "Setting Additional protections for public package registries to $ALLOW_TEAM_ADMINS_INVITATIONS_ACCESS_TOKEN"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowTeamAdminsInvitationsAccessToken?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ALLOW_TEAM_ADMINS_INVITATIONS_ACCESS_TOKEN'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowTeamAdminsInvitationsAccessToken?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Additional protections for public package registries policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Additional protections for public package registries policy was successful"
    fi
    ALLOW_GUEST_USERS=$(echo "$DEFAULT_JSON" | jq -r '.policies.disallow_external_guest_access')
    echo "Setting Allow guest users to $ALLOW_GUEST_USERS"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowAadGuestUserAccess?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ALLOW_GUEST_USERS'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.DisallowAadGuestUserAccess?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Allow guest users policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Allow guest users policy was successful"
    fi
    REQUEST_ACCESS=$(echo "$DEFAULT_JSON" | jq -r '.policies.request_access.enable')
    REQUEST_ACCESS_URL=$(echo "$DEFAULT_JSON" | jq -r '.policies.request_access.url')
    echo "Skipping the configuration of the organization url"
    if  [  ! $REQUEST_ACCESS ]; then
        echo "Setting ${ORG_NAME} organization url to $REQUEST_ACCESS_URL"
        echo "URL: https://vssps.dev.azure.com/${ORG_NAME}/_apis/Organization/Collections/${ORG_ID}/Properties?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
                --request PATCH \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json-patch+json" \
                --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$ALLOW_GUEST_USERS'"}]' \
                "https://vssps.dev.azure.com/${ORG_NAME}/_apis/Organization/Collections/${ORG_ID}/Properties?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Error during the configuration of the organization url. $RESPONSE_BODY"
            return 1;
        else
            echo "SUCCESS: Configuration of the organization url was successful"
        fi
    fi
    echo "Setting Request access to $REQUEST_ACCESS"
    echo "URL: https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowRequestAccessToken?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
            --request PATCH \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json-patch+json" \
            --data-raw '[{"from":"","op":2,"path":"/Value","value":"'$REQUEST_ACCESS'"}]' \
            "https://dev.azure.com/${ORG_NAME}/_apis/OrganizationPolicy/Policies/Policy.AllowRequestAccessToken?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    if [ $HTTP_STATUS != 204 ]; then
        echo "ERROR: Error during the configuration of the Request access policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Request access policy was successful"
    fi
}