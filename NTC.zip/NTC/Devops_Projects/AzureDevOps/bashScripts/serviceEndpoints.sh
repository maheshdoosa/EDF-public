function create_service_endpoints {
    local ORG_ID=$1
    local ORG_NAME=$2
    local PROJECT_NAME=$3
    local DEFAULT_JSON=$4
    local PAT=$5
    echo "Create service endpoints in $PROJECT_NAME project"
    echo "Read the list of existing service endpoints"
    echo "URL: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/serviceendpoints?api-version=5.1-preview.1"
    RESPONSE=$(curl --silent \
            --request POST \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            --data-raw '{"contributionIds":["ms.vss-distributed-task.resources-hub-query-data-provider"],"dataProviderContext":{"properties":{"resourceFilters":{"createdBy":[],"resourceType":[],"searchText":""},"sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/adminservices","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"adminservices","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
            "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    SERVICE_ENDPOINT_LIST_RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Failed to get the list of existing service endpoints. $RESPONSE"
    else
        echo "SUCCESS: The list of existing service endpoints was succesfully retrieved"
    fi
    for SERVICE_ENDPOINT in $(echo "$DEFAULT_JSON" | jq -r '.service_endpoints[] | @base64'); do
        SERVICE_ENDPOINT_JSON=$(echo "$SERVICE_ENDPOINT" | base64 --decode | jq -r '.')
        echo "SERVICE_ENDPOINT_JSON: $SERVICE_ENDPOINT_JSON"
        echo "Creating Azure service endpoint"
        for AZURE_SERVICE_ENDPOINT in $(echo "$SERVICE_ENDPOINT_JSON" | jq -r '.azurerm[] | @base64'); do
            AZURE_SERVICE_ENDPOINT_JSON=$(echo "$AZURE_SERVICE_ENDPOINT" | base64 --decode | jq -r '.')
            echo "AZURE_SERVICE_ENDPOINT_JSON: $AZURE_SERVICE_ENDPOINT_JSON"
            NAME=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.name')
            echo "NAME: $NAME"
            TENANT_ID=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.tenant_id')
            echo "TENANT_ID: $TENANT_ID"
            SUBSCRIPTION_ID=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.subscription_id')
            echo "SUBSCRIPTION_ID: $SUBSCRIPTION_ID"
            SUBSCRIPTION_NAME=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.subscription_name')
            echo "SUBSCRIPTION_NAME: $SUBSCRIPTION_NAME"
            SERVICE_PRINCIPAL_ID=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.service_principal_id')
            echo "SERVICE_PRINCIPAL_ID: $SERVICE_PRINCIPAL_ID"
            export AZURE_DEVOPS_EXT_AZURE_RM_SERVICE_PRINCIPAL_KEY=$(echo "$AZURE_SERVICE_ENDPOINT_JSON" | jq -r '.service_principal_key')
            echo "Checking if $NAME service endpoint already exists"      
            if [ $(echo "$SERVICE_ENDPOINT_LIST_RESPONSE_BODY" | jq '.dataProviders."ms.vss-distributed-task.resources-hub-query-data-provider".resourceItems[] | select(.name == "'"$NAME"'") | length') -gt 0 ]; then
                echo "$NAME service endpoint already exists. Skipping..."
                continue
            else
                echo "$NAME service endpoint does not exist."
            fi
            echo "Creating $NAME service endpoint"
            echo "Command: az devops service-endpoint azurerm create --azure-rm-service-principal-id $SERVICE_PRINCIPAL_ID --azure-rm-subscription-id $SUBSCRIPTION_ID --azure-rm-subscription-name $SUBSCRIPTION_NAME --azure-rm-tenant-id $TENANT_ID --name $NAME --organization https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME --output json"
            RESPONSE=$(az devops service-endpoint azurerm create --azure-rm-service-principal-id "$SERVICE_PRINCIPAL_ID" --azure-rm-subscription-id "$SUBSCRIPTION_ID" --azure-rm-subscription-name "$SUBSCRIPTION_NAME" --azure-rm-tenant-id "$TENANT_ID" --name "$NAME" --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --output json)
            if [ $? -eq 0 ]; then
                echo "SUCCESS: The $NAME service endpoint was successfully created"
            else
                echo "ERROR: Error during the creation of the $NAME service endpoint"
                return 1
            fi
        done
        for GITHUB_SERVICE_ENDPOINT in $(echo "$SERVICE_ENDPOINT_JSON" | jq -r '.github[] | @base64'); do
            GITHUB_SERVICE_ENDPOINT_JSON=$(echo "$GITHUB_SERVICE_ENDPOINT" | base64 --decode | jq -r '.')
            echo "GITHUB_SERVICE_ENDPOINT_JSON: $GITHUB_SERVICE_ENDPOINT_JSON"
            NAME=$(echo "$GITHUB_SERVICE_ENDPOINT_JSON" | jq -r '.name')
            echo "NAME: $NAME"
            URL=$(echo "$GITHUB_SERVICE_ENDPOINT_JSON" | jq -r '.url')
            echo "URL: $URL"
            export AZURE_DEVOPS_EXT_GITHUB_PAT=$(echo "$GITHUB_SERVICE_ENDPOINT_JSON" | jq -r '.token')
            echo "Checking if $NAME service endpoint already exists"  
            if [[ $(echo "$SERVICE_ENDPOINT_LIST_RESPONSE_BODY" | jq '.dataProviders."ms.vss-distributed-task.resources-hub-query-data-provider".resourceItems[] | select(.name == "'"$NAME"'") | length') -gt 0 ]]; then
                echo "$NAME service endpoint already exists. Skipping..."
                continue
            else
                echo "$NAME service endpoint does not exist."
            fi
            echo "Creating $NAME service endpoint"
            echo "Command: az devops service-endpoint github create --github-url $URL --name $NAME --organization https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME --output json"
            RESPONSE=$(az devops service-endpoint github create --github-url "$URL" --name "$NAME" --organization "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --output json)
            if [ $? -eq 0 ]; then
                echo success "The $NAME service endpoint was successfully created"
            else
                echo error "Error during the creation of the $NAME service endpoint"
                return 1
            fi
        done
    done
}