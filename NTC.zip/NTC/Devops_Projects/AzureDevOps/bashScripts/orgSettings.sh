function configure_organization_settings {
    local ORG_ID=$1
    local ORG_NAME=$2
    local DEFAULT_JSON=$3
    local PAT=$4
    echo "Configure $ORG_NAME organization settings"  
    DISABLE_ANONYMOUS_ACCESS_BADGES=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_anonymous_access_badges')
    echo "Setting Disable anonymous access badges to $DISABLE_ANONYMOUS_ACCESS_BADGES"
    echo verbose "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"badgesArePublic":"'$DISABLE_ANONYMOUS_ACCESS_BADGES'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo verbose "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable anonymous access badges policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable anonymous access badges policy was successful"
    fi
    LIMIT_VARIABLES_SET_QUEUE_TIME=$(echo "$DEFAULT_JSON" | jq -r '.settings.limit_variables_set_queue_time')
    echo "Setting Limit variables set at queue time to $LIMIT_VARIABLES_SET_QUEUE_TIME"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"enforceSettableVar":"'$LIMIT_VARIABLES_SET_QUEUE_TIME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Limit variables set at queue time policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Limit variables set at queue time policy was successful"
    fi
    LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_NON_RELEASE_PIPELINES=$(echo "$DEFAULT_JSON" | jq -r '.settings.limit_job_authorization_current_project_non_release_pipelines')
    echo "Setting Limit job authorization scope to current project for non-release pipelines to $LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_NON_RELEASE_PIPELINES"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"enforceJobAuthScope":"'$LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_NON_RELEASE_PIPELINES'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Limit job authorization scope to current project for non-release pipelines policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Limit job authorization scope to current project for non-release pipelines policy was successful"
    fi
    LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_RELEASE_PIPELINES=$(echo "$DEFAULT_JSON" | jq -r '.settings.limit_job_authorization_current_project_release_pipelines')
    echo "Setting Limit job authorization scope to current project for release pipelines to $LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_NON_RELEASE_PIPELINES"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"enforceJobAuthScopeForReleases":"'$LIMIT_JOB_AUTHORIZATION_CURRENT_PROJECT_RELEASE_PIPELINES'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Limit job authorization scope to current project for release pipelines policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Limit job authorization scope to current project for release pipelines policy was successful"
    fi
    PROJECT_ACCESS_REPOSITORIES_YAML_PIPELINES=$(echo "$DEFAULT_JSON" | jq -r '.settings.protect_access_repositories_yaml_pipelines')
    echo "Setting Protect access to repositories for YAML pipelines to $PROJECT_ACCESS_REPOSITORIES_YAML_PIPELINES"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"enforceReferencedRepoScopedToken":"'$PROJECT_ACCESS_REPOSITORIES_YAML_PIPELINES'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Protect access to repositories for YAML pipelines policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Protect access to repositories for YAML pipelines policy was successful"
    fi
    DISABLE_STAGE_CHOOSER=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_stage_chooser')
    echo "Setting Disable stage chooser to $DISABLE_STAGE_CHOOSER"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"disableStageChooser":"'$DISABLE_STAGE_CHOOSER'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable stage chooser policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable stage chooser policy was successful"
    fi
    DISABLE_CREATION_CLASSIC_BUILD_AND_CLASSIC_RELEASE_PIPELINES=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_creation_classic_build_and_classic_release_pipelines')
    echo "Setting Disable creation of classic build and classic release pipelines to $DISABLE_CREATION_CLASSIC_BUILD_AND_CLASSIC_RELEASE_PIPELINES"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"disableClassicPipelineCreation":"'$DISABLE_CREATION_CLASSIC_BUILD_AND_CLASSIC_RELEASE_PIPELINES'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable creation of classic build and classic release pipelines policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable creation of classic build and classic release pipelines policy was successful"
    fi
    DISABLE_BUILD_IN_TASKS=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_built_in_tasks')
    echo "Setting Disable built-in tasks to $DISABLE_BUILD_IN_TASKS"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"disableInBoxTasksVar":"'$DISABLE_BUILD_IN_TASKS'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable built-in tasks policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable built-in tasks policy was successful"
    fi
    DISABLE_MARKETPLACE_TASKS=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_marketplace_tasks')
    echo "Setting Disable marketplace tasks to $DISABLE_MARKETPLACE_TASKS"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"disableMarketplaceTasksVar":"'$DISABLE_MARKETPLACE_TASKS'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable built-in tasks policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable built-in tasks policy was successful"
    fi
    DISABLE_NODE_SIX_TASKS=$(echo "$DEFAULT_JSON" | jq -r '.settings.disable_node_six_tasks')
    echo "Setting Disable Node 6 tasks to $DISABLE_NODE_SIX_TASKS"
    echo "URL: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
    RESPONSE=$(curl --silent \
        --request POST \
        --write-out "\n%{http_code}" \
        --header "Authorization: Basic $(echo -n :$PAT | base64)" \
        --header "Content-Type: application/json" \
        --data-raw '{"contributionIds":["ms.vss-build-web.pipelines-org-settings-data-provider"],"dataProviderContext":{"properties":{"disableNode6Tasksvar":"'$DISABLE_NODE_SIX_TASKS'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/_settings/pipelinessettings","routeId":"ms.vss-admin-web.collection-admin-hub-route","routeValues":{"adminPivot":"pipelinessettings","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
        "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    echo "Response code: $HTTP_STATUS"
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the configuration of the Disable built-in tasks policy. $RESPONSE_BODY"
        return 1;
    else
        echo "SUCCESS: Configuration of the Disable built-in tasks policy was successful"
    fi
}