function assing_security_groups_to_environments {
    local ORG_NAME=$1
    local PROJECT_ID=$2
    local PROJECT_NAME=$3
    local DEFAULT_JSON=$4
    local PAT=$5
    echo "Assign security groups to environments in $PROJECT_NAME project"
    for ENVIRONMENT in $(echo "$DEFAULT_JSON" | jq -r '.environments[] | @base64'); do
        ENVIRONMENT_JSON=$(echo "$ENVIRONMENT" | base64 --decode | jq -r '.')
        echo "ENVIRONMENT_JSON: $ENVIRONMENT_JSON"
        ENVIRONMENT_NAME=$(echo "$ENVIRONMENT_JSON" | jq -r '.name')
        echo "ENVIRONMENT_NAME: $ENVIRONMENT_NAME"
        for SECURITY_GROUP in $(echo "${ENVIRONMENT_JSON}" | jq -r '.security_groups_name[] | @base64'); do
            SECURITY_GROUP_JSON=$(echo "${SECURITY_GROUP}" | base64 --decode)
            echo "SECURITY_GROUP_JSON: $SECURITY_GROUP_JSON"
            NAME=$(echo "${SECURITY_GROUP_JSON}" | jq -r '.name')
            echo "NAME: $NAME"
            ROLE=$(echo "${SECURITY_GROUP_JSON}" | jq -r '.role_name')
            echo "ROLE: $ROLE"
            echo "Get security group ID for $NAME"
            SECURITY_GROUP_ID=$(az devops security group list --project $PROJECT_NAME --org https://dev.azure.com/$ORG_NAME --output json | jq -r '.graphGroups[] | select(.displayName == "'"$NAME"'") | .originId')
            if [ $? -eq 0 ]; then
                echo "SUCCESS: The ID of the $NAME security group is $SECURITY_GROUP_ID"
            else
                echo "ERROR: Error during the reading of the property ID of the $NAME security group"
                return 1
            fi
            echo "Get evnironment ID by $ENVIRONMENT_NAME"
            echo "Url: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1"
            RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                "https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1")
            HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
            echo "Response code: $HTTP_STATUS"
            RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
            if [ $HTTP_STATUS != 200 ]; then
                echo "ERROR: Failed to get the $NAME environment ID. $RESPONSE"
                return 1;
            else
                echo "SUCCESS: The ID of the $ENVIRONMENT_NAME environment was succesfully retrieved"
            fi
            ENVIRONMENT_ID=$(echo "$RESPONSE_BODY" | jq '.value[] | select(.name == "'"$ENVIRONMENT_NAME"'") | .id' | tr -d '"')  
            echo "ENVIRONMENT_ID: $ENVIRONMENT_ID"
            echo "Associate the $NAME security group to the $ENVIRONMENT_NAME environment"
            echo "Request: '[{"roleName": "'"$ROLE"'","userId": "'"$SECURITY_GROUP_ID"'"}]'"
            echo "Url: https://dev.azure.com/$ORG_NAME/_apis/securityroles/scopes/distributedtask.environmentreferencerole/roleassignments/resources/$PROJECT_ID"_"$ENVIRONMENT_ID?api-version=5.0-preview.1"
            RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --request PUT \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '[{"roleName": "'"$ROLE"'","userId": "'"$SECURITY_GROUP_ID"'"}]' \
                "https://dev.azure.com/$ORG_NAME/_apis/securityroles/scopes/distributedtask.environmentreferencerole/roleassignments/resources/$PROJECT_ID"_"$ENVIRONMENT_ID?api-version=5.0-preview.1")
            HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
            echo "Response code: $HTTP_STATUS"
            RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
            if [ $HTTP_STATUS != 200 ]; then
                echo "ERROR: Failed to associate the $NAME security group to the $ENVIRONMENT_NAME environment. $RESPONSE"
                return 1;
            else
                echo "SUCCESS: The $NAME security group was successfully associated to the $ENVIRONMENT_NAME environment"
            fi
        done
    done
}