function create_repositories_branch_protection_policies {
    local ORG_NAME=$1
    local PROJECT_NAME=$2
    local DEFAULT_JSON=$3
    local PAT=$4
    echo "Creating branch protection policies in the $PROJECT_NAME project"
    echo "$ORG_NAME ===== ===== $DEFAULT_JSON "   
    echo "Creating Approver count policies"
    for APPROVER_COUNT_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.approver_count[]  | @base64'); do
        APPROVER_COUNT_POLICY_JSON=$(echo "$APPROVER_COUNT_POLICY"  | base64 --decode | jq -r '.')
        echo "APPROVER_COUNT_POLICY_JSON: $APPROVER_COUNT_POLICY_JSON"
        REPO_NAME=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        ALLOW_DOWNVOTES=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.allow_downvotes')
        echo "ALLOW_DOWNVOTES: $ALLOW_DOWNVOTES"
        CREATOR_VOTE_COUNT=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.creator_vote_counts')
        echo "CREATOR_VOTE_COUNT: $CREATOR_VOTE_COUNT"
        MINIMAL_APPROVER_COUNT=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.minimum_approver_count')
        echo "MINIMAL_APPROVER_COUNT: $MINIMAL_APPROVER_COUNT"
        RESET_ON_SOURCE_PUSH=$(echo "$APPROVER_COUNT_POLICY_JSON" | jq -r '.reset_on_source_push')
        echo "RESET_ON_SOURCE_PUSH: $RESET_ON_SOURCE_PUSH"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository $REPO_NAME --query id --output tsv --org https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME"
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo "ERROR: Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi     
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing approver count policies. $RESPONSE"
            return 1;
        else
            echo "SUCCESS: The list of existing approver count policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."fa4e907d-c16b-4a4c-9dfa-4906e5d171dd".currentScopePolicies | length > 0') == true ]; then
            echo warning "The approver count policy already exists. Skipping..."
            continue
        else 
            echo "Creating approver count policy for the $BRANCH_NAME in $REPO_NAME repository"
        fi
        echo "Creating approver count policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "Command: az repos policy approver-count create --branch-match-type $BRANCH_MATCH_TYPE --allow-downvotes $ALLOW_DOWNVOTES --blocking true --branch $BRANCH_NAME --creator-vote-counts $CREATOR_VOTE_COUNT --enabled true --minimum-approver-count $MINIMAL_APPROVER_COUNT --repository-id $REPO_ID --reset-on-source-push $RESET_ON_SOURCE_PUSH --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME""
        az repos policy approver-count create --branch-match-type $BRANCH_MATCH_TYPE --allow-downvotes $ALLOW_DOWNVOTES --blocking true --branch $BRANCH_NAME --creator-vote-counts $CREATOR_VOTE_COUNT --enabled true --minimum-approver-count $MINIMAL_APPROVER_COUNT --repository-id $REPO_ID --reset-on-source-push $RESET_ON_SOURCE_PUSH --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Approver count policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Approver count policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done

    echo "Creating comment required policies"
    for COMMENT_REQUIRED_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.comment_required[] | @base64'); do
        COMMENT_REQUIRED_POLICY_JSON=$(echo "$COMMENT_REQUIRED_POLICY" | base64 --decode | jq -r '.')
        echo "COMMENT_REQUIRED_POLICY_JSON: $COMMENT_REQUIRED_POLICY_JSON"
        REPO_NAME=$(echo "$COMMENT_REQUIRED_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$COMMENT_REQUIRED_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$COMMENT_REQUIRED_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME""
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        echo "REPO_ID: $REPO_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo error  "Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        # Comment requirements
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        echo "Response body: $RESPONSE_BODY"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing approver count policies. $RESPONSE"
            exit 1;
        else
            echo "SUCCESS: The list of existing approver count policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."c6a1889d-b943-4856-b76f-9e46bb6b0df2".currentScopePolicies | length > 0') == true ]; then
            echo "The approver count policy already exists. Skipping..."
            continue
        fi
        echo "Creating comment required policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "Command: az repos policy comment-required create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --enabled true --repository-id $REPO_ID --project \"$PROJECT_NAME\" --organization \"https://dev.azure.com/$ORG_NAME\""
        az repos policy comment-required create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --enabled true --repository-id $REPO_ID --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Comment required policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Comment required policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done

    echo "Creating merge strategy policies"
    for MERGE_STRATEGY_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.merge_strategy[] | @base64'); do
        MERGE_STRATEGY_POLICY_JSON=$(echo "$MERGE_STRATEGY_POLICY" | base64 --decode | jq -r '.')
        echo "MERGE_STRATEGY_POLICY_JSON: $MERGE_STRATEGY_POLICY_JSON"
        REPO_NAME=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        ALLOW_NO_FAST_FORWARD=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.allow_no_fast_forward')
        echo "ALLOW_NO_FAST_FORWARD: $ALLOW_NO_FAST_FORWARD"
        ALLOW_REBASE=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.allow_rebase')
        echo "ALLOW_REBASE: $ALLOW_REBASE"
        ALLOW_REBASE_MERGE=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.allow_rebase_merge')
        echo "ALLOW_REBASE_MERGE: $ALLOW_REBASE_MERGE"
        ALLOW_SQUASH=$(echo "$MERGE_STRATEGY_POLICY_JSON" | jq -r '.allow_squash')
        echo "ALLOW_SQUASH: $ALLOW_SQUASH"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository \"$REPO_NAME\" --query id --output tsv --org \"https://dev.azure.com/$ORG_NAME\" --project \"$PROJECT_NAME\""
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        echo "REPO_ID: $REPO_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo error  "Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        # "Check if the pull request has any active comments" = "fa4e907d-c16b-4a4c-9dfa-4916e5d171ab"
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        echo "REFNAME: $REFNAME"
        echo "Url: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        echo "Response body: $RESPONSE_BODY"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing comment required policies. $RESPONSE"
            return 1;
        else
            echo "SUCCESS: The list of existing comment required policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."fa4e907d-c16b-4a4c-9dfa-4916e5d171ab".currentScopePolicies | length > 0') == true ]; then
            echo warning "The comment required policy already exists. Skipping..."
            continue
        fi
        echo "Creating merge strategy policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "az repos policy merge-strategy create --allow-no-fast-forward $ALLOW_NO_FAST_FORWARD --allow-rebase $ALLOW_REBASE --allow-rebase-merge $ALLOW_REBASE_MERGE --allow-squash $ALLOW_SQUASH --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --enabled true --repository-id $REPO_ID --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME""
        az repos policy merge-strategy create \
            --allow-no-fast-forward $ALLOW_NO_FAST_FORWARD \
            --allow-rebase $ALLOW_REBASE \
            --allow-rebase-merge $ALLOW_REBASE_MERGE \
            --allow-squash $ALLOW_SQUASH \
            --branch-match-type $BRANCH_MATCH_TYPE \
            --branch $BRANCH_NAME \
            --blocking true \
            --enabled true \
            --repository-id $REPO_ID \
            --project "$PROJECT_NAME" \
            --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Comment required policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Comment required policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done

    echo "Creating work-item linking policies"
    for WORK_ITEM_LINKING_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.work_item_linking[] | @base64'); do
        WORK_ITEM_LINKING_POLICY_JSON=$(echo "$WORK_ITEM_LINKING_POLICY" | base64 --decode | jq -r '.')
        echo "WORK_ITEM_LINKING_POLICY_JSON: $WORK_ITEM_LINKING_POLICY_JSON"
        REPO_NAME=$(echo "$WORK_ITEM_LINKING_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$WORK_ITEM_LINKING_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$WORK_ITEM_LINKING_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository \"$REPO_NAME\" --query id --output tsv --org \"https://dev.azure.com/$ORG_NAME\" --project \"$PROJECT_NAME\""
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        echo "REPO_ID: $REPO_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo error  "Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        echo "REFNAME: $REFNAME"
        echo 'Request: {"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}'
        echo "Url: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/contribution/hierarchyquery"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        echo "Response body: $RESPONSE_BODY"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing approver count policies. $RESPONSE"
            return 1;
        else
            echo "SUCCESS: The list of existing approver count policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."40e92b44-2fe1-4dd6-b3d8-74a9c21d0c6e".currentScopePolicies | length > 0') == true ]; then
            echo "The approver count policy already exists. Skipping..."
            continue
        fi
        echo "Creating work-item linking policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "Command: az repos policy work-item-linking create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --enabled true --repository-id $REPO_ID --project \"$PROJECT_NAME\" --organization \"https://dev.azure.com/$ORG_NAME\""
        az repos policy work-item-linking create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --enabled true --repository-id $REPO_ID --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Work-item linking policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Work-item linking policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done

    echo "Creating required reviewers policies"
    for REQUIRED_REVIEWERS_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.required_reviewer[] | @base64'); do
        REQUIRED_REVIEWERS_POLICY_JSON=$(echo "$REQUIRED_REVIEWERS_POLICY" | base64 --decode | jq -r '.')
        echo "REQUIRED_REVIEWERS_POLICY_JSON: $REQUIRED_REVIEWERS_POLICY_JSON"
        REPO_NAME=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        REQUIRED_REVIEWER_EMAILS=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.required_reviewer_emails') 
        echo "REQUIRED_REVIEWER_EMAILS: $REQUIRED_REVIEWER_EMAILS"
        MESSAGE=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.message')
        echo "MESSAGE: $MESSAGE"
        PATH_FILTER=$(echo "$REQUIRED_REVIEWERS_POLICY_JSON" | jq -r '.path_filter')
        echo "PATH_FILTER: $PATH_FILTER"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository \"$REPO_NAME\" --query id --output tsv --org \"https://dev.azure.com/$ORG_NAME\" --project \"$PROJECT_NAME\""
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        echo "REPO_ID: $REPO_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo error  "Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        echo "REFNAME: $REFNAME"
        echo 'Request: {"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}'
        echo "Url: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        echo "Response body: $RESPONSE_BODY"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing approver count policies. $RESPONSE"
            return 1;
        else
            echo "SUCCESS: The list of existing approver count policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."fd2167ab-b0be-447a-8ec8-39368250530e".currentScopePolicies | length > 0') == true ]; then
            echo "The approver count policy already exists. Skipping..."
            continue
        fi
        echo "Creating required reviewers policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "Command: az repos policy required-reviewer create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --message "$MESSAGE" --path-filter "$PATH_FILTER" --enabled true --required-reviewer-ids "$REQUIRED_REVIEWER_EMAILS" --repository-id $REPO_ID --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME""
        az repos policy required-reviewer create \
            --branch-match-type $BRANCH_MATCH_TYPE \
            --branch $BRANCH_NAME \
            --blocking true \
            --message "$MESSAGE" \
            --path-filter "$PATH_FILTER" \
            --enabled true \
            --required-reviewer-ids "$REQUIRED_REVIEWER_EMAILS" \
            --repository-id $REPO_ID \
            --project "$PROJECT_NAME" \
            --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Required reviewers policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Required reviewers policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done

    echo "Creating build policies"
    for BUILD_POLICY in $(echo "$DEFAULT_JSON" | jq -r '.policies.build[] | @base64'); do
        BUILD_POLICY_JSON=$(echo "$BUILD_POLICY" | base64 --decode | jq -r '.')
        echo "BUILD_POLICY_JSON: $BUILD_POLICY_JSON"
        REPO_NAME=$(echo "$BUILD_POLICY_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        BRANCH_NAME=$(echo "$BUILD_POLICY_JSON" | jq -r '.branch_name')
        echo "BRANCH_NAME: $BRANCH_NAME"
        BRANCH_MATCH_TYPE=$(echo "$BUILD_POLICY_JSON" | jq -r '.branch_match_type')
        echo "BRANCH_MATCH_TYPE: $BRANCH_MATCH_TYPE"
        VALID_DURATION=$(echo "$BUILD_POLICY_JSON" | jq -r '.valid_duration') 
        echo "VALID_DURATION: $VALID_DURATION"
        QUEUE_ON_SOURCE_UPDATE_ONLY=$(echo "$BUILD_POLICY_JSON" | jq -r '.queue_on_source_update_only')
        echo "QUEUE_ON_SOURCE_UPDATE_ONLY: $QUEUE_ON_SOURCE_UPDATE_ONLY"
        MANUAL_QUEUE_ONLY=$(echo "$BUILD_POLICY_JSON" | jq -r '.manual_queue_only')
        echo "MANUAL_QUEUE_ONLY: $MANUAL_QUEUE_ONLY"
        DISPLAY_NAME=$(echo "$BUILD_POLICY_JSON" | jq -r '.display_name')
        echo "DISPLAY_NAME: $DISPLAY_NAME"
        BUILD_DEFINITION_NAME=$(echo "$BUILD_POLICY_JSON" | jq -r '.build_definition_name')
        echo "BUILD_DEFINITION_NAME: $BUILD_DEFINITION_NAME"
        echo "Reading ID of the $REPO_NAME repository"
        echo "Command: az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME""
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        echo "REPO_ID: $REPO_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo error  "Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        echo "Reading ID of the $BUILD_DEFINITION_NAME build definition"
        echo "Command: az pipelines build definition show --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --name $BUILD_DEFINITION_NAME"
        BUILD_DEFINITION_ID=$(az pipelines build definition show --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME" --name $BUILD_DEFINITION_NAME)
        echo "BUILD_DEFINITION_ID: $BUILD_DEFINITION_ID"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $BUILD_DEFINITION_NAME build definition is $BUILD_DEFINITION_ID"
        else
            echo error  "Error during the reading of the property ID of the $BUILD_DEFINITION_NAME"
            return 1
        fi
        # "Build" = "0609b952-1397-4640-95ec-e00a01b2c241"
        REFNAME="refs/heads/$( if [ $BRANCH_MATCH_TYPE == "exact" ]; then echo "$BRANCH_NAME"; else echo "$BRANCH_NAME/*"; fi )"
        echo "REFNAME: $REFNAME"
        echo '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}'
        echo "Uri: https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
                --write-out "\n%{http_code}" \
                --header "Authorization: Basic $(echo -n :$PAT | base64)" \
                --header "Content-Type: application/json" \
                --data-raw '{"contributionIds":["ms.vss-code-web.branch-policies-data-provider"],"dataProviderContext":{"properties":{"projectId":"'$PROJECT_ID'","repositoryId":"'$REPO_ID'","refName":"'$REFNAME'","sourcePage":{"url":"https://dev.azure.com/'$ORG_NAME'/'$PROJECT_NAME'/_settings/repositories?_a=policiesMid&repo='$REPO_ID'&refs='$REFNAME'","routeId":"ms.vss-admin-web.project-admin-hub-route","routeValues":{"project":"'$PROJECT_NAME'","adminPivot":"repositories","controller":"ContributedPage","action":"Execute","serviceHost":"'$ORG_ID' ('$ORG_NAME')"}}}}}' \
                "https://dev.azure.com/$ORG_NAME/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        echo "Response body: $RESPONSE_BODY"
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to retrieve the list of existing approver count policies. $RESPONSE"
            return 1;
        else
            echo "SUCCESS: The list of existing approver count policies was successfully retrieved"
        fi
        if [ $(echo $RESPONSE_BODY | jq '.dataProviders."ms.vss-code-web.branch-policies-data-provider".policyGroups."0609b952-1397-4640-95ec-e00a01b2c241".currentScopePolicies | length > 0') == true ]; then
            echo "The approver count policy already exists. Skipping..."
            continue
        fi
        echo "Creating required reviewers policy for the $BRANCH_NAME in $REPO_NAME repository"
        echo "az repos policy build create --branch-match-type $BRANCH_MATCH_TYPE --branch $BRANCH_NAME --blocking true --build-definition-id "$BUILD_DEFINITION_ID" --display-name "$DISPLAY_NAME" --manual-queue-only $MANUAL_QUEUE_ONLY --queue-on-source-update-only $QUEUE_ON_SOURCE_UPDATE_ONLY --valid-duration $VALID_DURATION --enabled true --repository-id $REPO_ID --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME""
        az repos policy build create \
            --branch-match-type $BRANCH_MATCH_TYPE \
            --branch $BRANCH_NAME \
            --blocking true \
            --build-definition-id "$BUILD_DEFINITION_ID" \
            --display-name "$DISPLAY_NAME" \
            --manual-queue-only $MANUAL_QUEUE_ONLY \
            --queue-on-source-update-only $QUEUE_ON_SOURCE_UPDATE_ONLY \
            --valid-duration $VALID_DURATION \
            --enabled true \
            --repository-id $REPO_ID \
            --project "$PROJECT_NAME" \
            --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo "SUCCESS: Required reviewers policy was added to $BRANCH_NAME in $REPO_NAME repository"
        else
            echo "ERROR: Required reviewers policy was not added to $BRANCH_NAME in $REPO_NAME repository"
            return 1
        fi
    done
}