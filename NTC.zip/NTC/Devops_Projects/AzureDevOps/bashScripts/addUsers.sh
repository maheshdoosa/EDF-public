function add_users_to_organization {
    local ORG_NAME=$1
    local DEFAULT_JSON=$2
    log "Adding users to $ORG_NAME organization"
    for USER in $(echo "$DEFAULT_JSON" | jq -r '.organization.users[] | @base64'); do
        USER_JSON=$(echo "$USER" | base64 --decode | jq -r '.')
        log verbose "User: $USER_JSON"
        NAME=$(echo "$USER_JSON" | jq -r '.name')
        log verbose "NAME: $NAME"
        EMAIL=$(echo "$USER_JSON" | jq -r '.email')
        log verbose "EMAIL: $EMAIL"
        log "Checking if user $NAME ($EMAIL) is already a member of $ORG_NAME organization"
        log verbose "Command: az devops user show --user $EMAIL --organization https://dev.azure.com/$ORG_NAME"
        RESPONSE=$(az devops user show --user $EMAIL --organization "https://dev.azure.com/$ORG_NAME")
        if [ -z "$RESPONSE" ]; then
            log success "User $NAME ($EMAIL) is not a member of $ORG_NAME organization"
        else
            log warning  "User $NAME ($EMAIL) is already a member of $ORG_NAME organization. Skipping..."
            continue
        fi
        log "Adding user $NAME ($EMAIL) to $ORG organization"
        log verbose "Command: az devops user add --email-id $EMAIL --license-type express --send-email-invite false --organization https://dev.azure.com/$ORG_NAME"
        az devops user add --email-id "$EMAIL" --license-type "express" --send-email-invite false --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            log success "User $NAME ($EMAIL) was added to $ORG_NAME organization"
        else
            log error "User $NAME ($EMAIL) was not added to $ORG_NAME organization"
            return 1
        fi
    done
}