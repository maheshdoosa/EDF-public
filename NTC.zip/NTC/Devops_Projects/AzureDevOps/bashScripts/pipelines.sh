function create_pipeline_pipelines {
    local ORG_NAME=$1
    local PROJECT_NAME=$2
    local DEFAULT_JSON=$3
    local PAT=$4
    echo "Creating pipelines in $PROJECT_NAME project"
    for PIPELINE in $(echo "$DEFAULT_JSON" | jq -r '.pipelines[] | @base64'); do
        PIPELINE_JSON=$(echo "$PIPELINE" | base64 --decode | jq -r '.')
        echo "PIPELINE_JSON: $PIPELINE_JSON"
        NAME=$(echo "$PIPELINE_JSON" | jq -r '.name')
        echo "NAME: $NAME"
        REPO_NAME=$(echo "$PIPELINE_JSON" | jq -r '.repository_name')
        echo "REPO_NAME: $REPO_NAME"
        FOLDER_NAME=$(echo "$PIPELINE_JSON" | jq -r '.folder_name')
        echo "FOLDER_NAME: $FOLDER_NAME"
        PIPELINE_PATH=$(echo "$PIPELINE_JSON" | jq -r '.pipeline_path')
        echo "PIPELINE_PATH: $PIPELINE_PATH"
        echo "Checking if $NAME pipeline already exists"
        echo "az pipelines show --name $NAME --project $PROJECT_NAME --org https://dev.azure.com/$ORG_NAME"
        RESPONSE=$(az pipelines show --name "$NAME" --project "$PROJECT_NAME" --org "https://dev.azure.com/$ORG_NAME")
        if [ -z "$RESPONSE" ]; then
            echo "$NAME piepline does not exist"
        else
            echo "WARNING: $NAME piepline already exists. Skipping..."
            continue
        fi
        echo "Reading ID of the $REPO_NAME repository"
        echo "az repos show --repository $REPO_NAME --query id --output tsv --org https://dev.azure.com/$ORG_NAME --project $PROJECT_NAME"
        REPO_ID=$(az repos show --repository "$REPO_NAME" --query id --output tsv --org "https://dev.azure.com/$ORG_NAME" --project "$PROJECT_NAME")
        if [ $? -eq 0 ]; then
            echo "SUCCESS: The ID of the $REPO_NAME repository is $REPO_ID"
        else
            echo  "ERROR: Error during the reading of the property ID of the $REPO_NAME"
            return 1
        fi
        echo "Creating $NAME pipeline..."
        echo 'Request: {"folder": "'$FOLDER_NAME'","name": "'$NAME'","configuration": {"type": "yaml","path": "'$PIPELINE_PATH'","repository": {"id": "'$REPO_ID'","name": "'$REPO_NAME'","type": "azureReposGit"}}}'
        echo "Url: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/pipelines?api-version=7.0"
        RESPONSE=$(curl --silent \
            --write-out "\n%{http_code}" \
            --request POST \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            --data-raw '{"folder": "'$FOLDER_NAME'","name": "'$NAME'","configuration": {"type": "yaml","path": "'$PIPELINE_PATH'","repository": {"id": "'$REPO_ID'","name": "'$REPO_NAME'","type": "azureReposGit"}}}' \
            "https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/pipelines?api-version=7.0")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to create $NAME pipeline. $RESPONSE_BODY"
            return 1;
        else
            echo "SUCCESS: $NAME pipeline created successfully"
        fi
    done
}