function get_organization_id {
    local ORG_NAME=$1
    local PAT=$2
    RESPONSE=$(curl --silent \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            --data-raw '{"contributionIds": ["ms.vss-features.my-organizations-data-provider"],"dataProviderContext":{"properties":{}}}' \
            "https://dev.azure.com/${ORG_NAME}/_apis/Contribution/HierarchyQuery?api-version=5.0-preview.1")
    HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
    RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE")
    if [ $HTTP_STATUS != 200 ]; then
        echo "ERROR: Error during the reading of the organization ID"
        exit 1;                
    fi
    local ORG_ID=$(echo "$RESPONSE_BODY" | jq '.dataProviders."ms.vss-features.my-organizations-data-provider".organizations[] | select(.name == "'"$ORG_NAME"'") | .id' | tr -d '"')
    echo $ORG_ID
}