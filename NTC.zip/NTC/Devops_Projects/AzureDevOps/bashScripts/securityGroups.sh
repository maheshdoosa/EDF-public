function create_security_groups {
    local ORG_NAME=$1
    local PROJECT_NAME=$2
    local DEFAULT_JSON=$3
    echo "Creating security groups in the $PROJECT_NAME project"
    for SECURITY_GROUP in $(echo "$DEFAULT_JSON" | jq -r '.security_groups[] | @base64'); do
        SECURITY_GROUP_JSON=$(echo "$SECURITY_GROUP" | base64 --decode | jq -r '.')
        echo "Security group: $SECURITY_GROUP_JSON"
        NAME=$(echo "$SECURITY_GROUP_JSON" | jq -r '.name')
        echo "Security group name: $NAME" 
        DESCRIPTION=$(echo "$SECURITY_GROUP_JSON" | jq -r '.description')
        echo "Security group description: $DESCRIPTION"
        echo "Checking if $NAME security group already exists"
        echo "az devops security group list --project $PROJECT_NAME --organization https://dev.azure.com/$ORG_NAME"
        RESPONSE=$(az devops security group list --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME" | jq --arg name "$NAME" '.graphGroups[] | select(.displayName == $name) | length > 0')
        if [ "$RESPONSE" ]; then
            echo "WARNING: $NAME security group already exists. Skipping..."
            continue
        else
            echo "$NAME security group does not exist"
        fi
        echo "Creating $NAME security group in $PROJECT_NAME project"
        echo "az devops security group create --name $NAME --description '$DESCRIPTION' --project $PROJECT_NAME --organization https://dev.azure.com/$ORG_NAME --scope project"
        az devops security group create --name "$NAME" --description "$DESCRIPTION" --project "$PROJECT_NAME" --organization "https://dev.azure.com/$ORG_NAME" --scope project
        if [ $? -eq 0 ]; then
            echo "SUCCESS: User $NAME ($EMAIL) was added to $ORG_NAME organization"
        else
            echo "ERROR: User $NAME ($EMAIL) was not added to $ORG_NAME organization"
            return 1
        fi
    done
}