function create_pipeline_environments {
    local ORG_NAME=$1
    local PROJECT_NAME=$2
    local DEFAULT_JSON=$3
    local PAT=$4
    echo "Creating environments in $PROJECT_NAME project"
    for ENVIRONMENT in $(echo "$DEFAULT_JSON" | jq -r '.environments[] | @base64'); do
        ENVIRONMENT_JSON=$(echo "$ENVIRONMENT" | base64 --decode | jq -r '.')
        echo "ENVIRONMENT_JSON: $ENVIRONMENT_JSON"
        NAME=$(echo "$ENVIRONMENT_JSON" | jq -r '.name')
        echo "NAME: $NAME"
        DESCRIPTION=$(echo "$ENVIRONMENT_JSON" | jq -r '.description')
        echo "DESCRIPTION: $DESCRIPTION"
        echo "Url: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            "https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        if [ $HTTP_STATUS != 200 -a $(echo "$RESPONSE_BODY" | jq '.value[] | select(.name == "'"$NAME"'") | length') -gt 0 ]; then
            echo "WARNING: $NAME environment already exists. Skipping..."
            continue
        else
            echo "$NAME environment does not exist"
        fi
        echo "Creating $NAME environment..."
        echo "Request: {\"name\": \"$NAME\",\"description\": \"$DESCRIPTION\"}"
        echo "Url: https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1"
        RESPONSE=$(curl --silent \
            --write-out "\n%{http_code}" \
            --header "Authorization: Basic $(echo -n :$PAT | base64)" \
            --header "Content-Type: application/json" \
            --data-raw '{"name": "'"$NAME"'","description": "'"$DESCRIPTION"'"}' \
            "https://dev.azure.com/$ORG_NAME/$PROJECT_NAME/_apis/distributedtask/environments?api-version=5.0-preview.1")
        HTTP_STATUS=$(tail -n1 <<< "$RESPONSE")
        echo "Response code: $HTTP_STATUS"
        RESPONSE_BODY=$(sed '$ d' <<< "$RESPONSE") 
        if [ $HTTP_STATUS != 200 ]; then
            echo "ERROR: Failed to create $NAME environment. $RESPONSE"
        else
            echo "SUCCESS: Environment $NAME succesfully created"
        fi
    done
}