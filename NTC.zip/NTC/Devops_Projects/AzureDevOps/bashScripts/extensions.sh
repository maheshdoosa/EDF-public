function install_extensions_in_organization {
    local ORG_NAME=$1
    local DEFAULT_JSON=$2
    echo "Installing extensions in the $ORG_NAME organization"
    for EXRENSION in $(echo "$DEFAULT_JSON" | jq -r '.extensions[] | @base64'); do
        EXRENSION_JSON=$(echo "$EXRENSION" | base64 --decode | jq -r '.')
        echo "Extension: $EXRENSION_JSON"
        ID=$(echo "$EXRENSION_JSON" | jq -r '.id')
        echo "ID: $ID"
        PUBLISHER_ID=$(echo "$EXRENSION_JSON" | jq -r '.publisher_id')
        echo "PUBLISHER_ID: $PUBLISHER_ID"
        echo "Checking if $ID extension is already installed"
        echo "Command: az devops extension show --extension-id $ID --publisher-id $PUBLISHER_ID --organization https://dev.azure.com/$ORG_NAME"
        RESPONSE=$(az devops extension show --extension-id "$ID" --publisher-id "$PUBLISHER_ID" --organization "https://dev.azure.com/$ORG_NAME")
        if [ -z "$RESPONSE" ]; then
            echo "$ID is not installed"
        else
            echo warning "$ID is already installed. Skipping..."
            continue
        fi
        echo "Installing $ID extension in $ORG_NAME organization"
        echo "Command: az devops extension install --extension-id $ID --publisher-id $PUBLISHER_ID --organization https://dev.azure.com/$ORG_NAME"
        az devops extension install --extension-id "$ID" --publisher-id "$PUBLISHER_ID" --organization "https://dev.azure.com/$ORG_NAME"
        if [ $? -eq 0 ]; then
            echo success "Extension $ID was installed to $ORG_NAME organization"
        else
            echo error "Extension $ID was not installed to $ORG_NAME organization"
            return 1
        fi
    done
}