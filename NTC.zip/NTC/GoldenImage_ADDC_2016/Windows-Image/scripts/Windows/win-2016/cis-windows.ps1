C:\Users\CIS-windows-V1.1.0.ps1 -adminpassword $Env:win_passwd
# Write-Host \"running policy import\"
Start-Process powershell -Verb runAs "cmd /c secedit.exe /configure /db %windir%\security\local.sdb /cfg C:\\Users\\CIS-import-windows.inf"
$seed_admin = Get-Random -Minimum 1000 -Maximum 9999
$seed_guest = Get-Random -Minimum 1000 -Maximum 9999
$AdminNewAccountName = "DisabledUser$($seed_admin)"
$GuestNewAccountName = "DisabledUserSec$($seed_guest)"
Write-Host \" Rename Administrator Account \"
Rename-LocalUser -Name "Administrator" -NewName $AdminNewAccountName
Write-Host \" Rename Guest Account \"
Rename-LocalUser -Name "Guest" -NewName $GuestNewAccountName
C:\\Windows\\System32\\Sysprep\\sysprep.exe /generalize /shutdown /oobe
